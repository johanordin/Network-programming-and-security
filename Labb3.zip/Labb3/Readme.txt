author:Johan Nordin
liu-id:johno855

------------------------------
To run

1. Mark the folders Server and Client.
2. shift + right click.
3. Open command window here
4. In the server console enter "java SecureAdditionServer.java"
5. Server should now listen for clients to connect.
6. In the client console enter "java SecureAdditionClient.java"

